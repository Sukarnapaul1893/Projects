Select
	Year (m.release_data) as ReleaseYear,
	c.name as CinemaName,
	count(m.id) as NumberOfMovies
from movie m
Inner join movie_schedule ms
on ms.movie_id = m.id
Inner join schedule s
on s.id = ms.schedule_id
Inner join hall h
on h.id = s.hall_id
Inner join cinema c
on c.id = h.cinema_id
Group by
	c.name,
	Year (m.release_data)