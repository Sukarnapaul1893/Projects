Select distinct m.name, m.release_data, c.id, c.name
from movie m
INNER JOIN movie_schedule ms
on ms.movie_id = m.id 
INNER JOIN schedule s
on s.id = ms.schedule_id
INNER JOIN hall h	
on h.id = s.hall_id
INNER JOIN cinema c
on c.id = h.cinema_id
