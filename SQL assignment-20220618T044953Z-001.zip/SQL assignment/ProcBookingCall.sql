Declare @Answer int 
Execute SP @UserId = 3, @NumberOfTickets = 3, @MovieScheduleId = 2, @Result = @Answer out 
Print @Answer