alter proc SP 
@UserId int,
@NumberOfTickets int,
@MovieScheduleId int,
@Result int output
as 

begin

	Declare @totalCapacity int
	Declare @ticketPrice int
	
	Select @ticketPrice = ms.ticket_price, @totalCapacity = h.capacity
		from movie_schedule ms
		INNER JOIN schedule ss
		on ss.id = ms.schedule_id 
		INNER JOIN hall h
		on ss.hall_id = h.id
		where ms.id = @MovieScheduleId;

	Declare @remainingCapacity int
	Declare @bookedCapacity int
	Declare @alreadyBought int

	Select @bookedCapacity = Sum(number_of_seat) from booking where movie_schedule_id = @MovieScheduleId
	if(@bookedCapacity is null) select @bookedCapacity = 0

	Select @remainingCapacity = @totalCapacity - @bookedCapacity

	Select @alreadyBought = sum(number_of_seat) 
								from booking 
								where movie_schedule_id = @MovieScheduleId 
										and user_id = @UserId
	if(@alreadyBought is null) select @alreadyBought = 0
	

	if(@remainingCapacity < @NumberOfTickets)
		Select @Result = -1
	
	else if(@NumberOfTickets + @alreadyBought > 4)
		Select @Result = -2
	
	else
		Select @Result = @NumberOfTickets * @ticketPrice
	select @remainingCapacity as remaining
	select @NumberOfTickets
	select @alreadyBought as already
	select @bookedCapacity as b
	select @Result as result

	if(@NumberOfTickets + @alreadyBought <= 4 AND @remainingCapacity >= @NumberOfTickets) insert into booking(
		movie_schedule_id,
		user_id,
		number_of_seat
	)
	values(
		@MovieScheduleId,
		@UserId,
		@NumberOfTickets
	)
end