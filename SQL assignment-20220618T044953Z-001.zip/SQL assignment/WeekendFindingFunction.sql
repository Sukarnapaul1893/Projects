alter function Weekend(@HallId int)
returns @WeekendTable table(
		id int primary key identity (1,1),
		Weekends int
	)
as
begin
	Insert into @WeekendTable
	select 
		Weekends
	from (
		select 
			wd.id as Weekends,
			s.day as MovieDays,
			s.hall_id as Halls
		from Weekdays wd
		Left Join schedule s
		on s.day = wd.id and s.hall_id = @HallId
		) w
		
	where w.MovieDays is NULL
	
	return;
end;