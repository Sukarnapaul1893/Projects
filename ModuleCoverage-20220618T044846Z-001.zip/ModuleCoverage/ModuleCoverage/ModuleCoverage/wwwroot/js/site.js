﻿
var modalDiv; //new variable to store current modal div
var globalNameList;
var globalPercentageList;
var globalIsCoveredList;
var sorted;

var sortedByNameFlag;
var sortedByMostExperiencedDeveloperFlag;
var sortedByAverageCoveredPercentageFlag;
var sortedByTotalNumberOfDevelopersFlag;

function showModal(nameList,percentageList) {
    $('#myModal').modal("show");

    globalNameList = nameList;
    globalPercentageList = percentageList;
    sorted = false;

    document.getElementById('idModalBody').innerHTML = '';
    var len = nameList.length;

    for (var i = 0; i < len; i += 1) {
        document.getElementById('idModalBody').innerHTML += `<tr>
                                                                <td>${nameList[i]}</td>
                                                                <td>${percentageList[i]}</td>
                                                            </tr>`;
    }

}

function sortList() {
    $('#myModal').modal("show");

    var nameList = globalNameList;
    var percentageList = globalPercentageList;
  
    document.getElementById('idModalBody').innerHTML = '';
    var len = nameList.length;

    var combinedList = [];

    for (var i = 0; i < len; i++) {
        combinedList[percentageList[i]] = nameList[i];
    }

    if (sorted == false) {
        for (var i = 0; i < len; i++) {
            var _key = Object.keys(combinedList)[i];
            document.getElementById('idModalBody').innerHTML += `<tr>
                                                                <td>${combinedList[_key]}</td>
                                                                <td>${_key}</td>
                                                            </tr>`;
        }
        sorted = true;
    }
    else {
        for (var i = 0; i < len; i++) {
            document.getElementById('idModalBody').innerHTML += `<tr>
                                                                <td>${nameList[i]}</td>
                                                                <td>${percentageList[i]}</td>
                                                            </tr>`;
        }
        sorted = false;
    }

}

function closeModal() {
    $("#myModal").modal("hide");
}

function closeModal2() {
    $("#myModal").modal("hide");
}

function showModal2(c) {
    var len = c.length;
    globalIsCoveredList = c;
    for (var i = 0; i < len; i++) {
        EnableBox(i);
    }
    $('#myModal').modal("show");
    
}

function EnableBox(i) {
    var _check = document.getElementById("CoveredModules_" + i + "__IsCovered");
    var _textbox = document.getElementById("CoveredModules_" + i + "__Percentage");

    if (globalIsCoveredList[i] == "True" || _check.checked) {
        _textbox.removeAttribute("disabled");
    }
    else {
        _textbox.disabled = "true";
    }
}

function sortByNames(sortedByNameList,unsortedList) {

    if (sortedByNameFlag == undefined) sortedByNameFlag = false;

    var nameList;
    if (sortedByNameFlag) {
        nameList = unsortedList;
    }
    else {
        nameList = sortedByNameList;
    }
    
    PrintList(nameList);
    
    sortedByNameFlag = (!sortedByNameFlag);
}

function sortByMostExperiencedDeveloper(sortedByMostExperiencedDeveloperList, unsortedList) {

    if (sortedByMostExperiencedDeveloperFlag == undefined) sortedByMostExperiencedDeveloperFlag = false;

    var mostExperiencedDeveloperList;
    if (sortedByMostExperiencedDeveloperFlag) {
        mostExperiencedDeveloperList = unsortedList;
    }
    else {
        mostExperiencedDeveloperList = sortedByMostExperiencedDeveloperList;
    }
    
    PrintList(mostExperiencedDeveloperList);
    
    sortedByMostExperiencedDeveloperFlag = (!sortedByMostExperiencedDeveloperFlag);
}

function sortByMostExperiencedDeveloper(sortedByAverageCoveredPercentageList, unsortedList) {

    if (sortedByAverageCoveredPercentageFlag == undefined) sortedByAverageCoveredPercentageFlag = false;

    var averageCoveredPercentageList;
    if (sortedByAverageCoveredPercentageFlag) {
        averageCoveredPercentageList = unsortedList;
    }
    else {
        averageCoveredPercentageList = sortedByAverageCoveredPercentageList;
    }

    PrintList(averageCoveredPercentageList);
    
    sortedByAverageCoveredPercentageFlag = (!sortedByAverageCoveredPercentageFlag);
}

function sortByTotalNumberOfDevelopers(sortedByTotalNumberOfDevelopersList, unsortedList) {
    if (sortedByTotalNumberOfDevelopersFlag == undefined) sortedByTotalNumberOfDevelopersFlag = false;

    var totalNumberOfDevelopersList;
    if (sortedByTotalNumberOfDevelopersFlag) {
        totalNumberOfDevelopersList = unsortedList;
    }
    else {
        totalNumberOfDevelopersList = sortedByTotalNumberOfDevelopersList;
    }

    PrintList(totalNumberOfDevelopersList);
    
    sortedByTotalNumberOfDevelopersFlag = (!sortedByTotalNumberOfDevelopersFlag);
}

function PrintList(myList) {
    document.getElementById('table-body').innerHTML = '';
    var len = myList.length;
    for (var i = 0; i < len; i++) {
        document.getElementById('table-body').innerHTML += `<tr>
                                                                <td>${myList[i].name}</td>
                                                                <td>${myList[i].mostExperiencedDeveloper}</td>
                                                                <td>${myList[i].averageCoveredPercentage}</td>
                                                                <td>${myList[i].totalNumberOfDevelopers}</td>
                                                                <td>
                                                                    <a class="btn btn-primary btn-md" href="/Module/Edit/${myList.id}">Edit</a> |
                                                                    <a asp-action="Delete" asp-route-id="${myList[i].Id}" class="btn btn-danger btn-md">Delete</a>
                                                                </td>
                                                            </tr>`
    }
}