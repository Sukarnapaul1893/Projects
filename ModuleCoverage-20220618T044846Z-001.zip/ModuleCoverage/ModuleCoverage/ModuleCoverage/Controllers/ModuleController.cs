﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ModuleCoverage.Data;
using ModuleCoverage.Models;

namespace ModuleCoverage.Controllers
{
    public class ModuleController : Controller
    {
        private readonly ModuleCoverageContext _context;

        public ModuleController(ModuleCoverageContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            
            var _modules = _context.Module.Include(dm=>dm.DeveloperModules).ThenInclude(d=>d.Developer).Select(x => new ModuleView
            {
                Id = x.Id,
                Name = x.Name,
                MostExperiencedDeveloper = x.DeveloperModules.OrderByDescending(z=>z.Percentage).Select(n=>n.Developer.Name).First(),
                //AverageCoveredPercentage = x.DeveloperModules.Select(z => z.Percentage).ToList().Average(),
                TotalNumberOfDevelopers = x.DeveloperModules.Count() 
            });

            return View(await _modules.ToListAsync());
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name")] ModuleView moduleVM)
        {
            Module module = new Module();
            module.Id = moduleVM.Id;
            module.Name = moduleVM.Name;

            if (ModelState.IsValid)
            {
                _context.Add(module);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            return View(module);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var module = await _context.Module.FindAsync(id);
            if (module == null)
            {
                return NotFound();
            }
            return View(module);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name")] ModuleView moduleVM)
        {
            if (id != moduleVM.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                Module module = new Module
                {
                    Id = moduleVM.Id,
                    Name = moduleVM.Name,
                };

                try
                {
                    _context.Update(module);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ModuleExists(module.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(moduleVM);
        }

        private bool ModuleExists(int id)
        {
            return _context.Module.Any(e => e.Id == id);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var module = await _context.Module
                .FirstOrDefaultAsync(m => m.Id == id);
            if (module == null)
            {
                return NotFound();
            }

            return View(module);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var module = await _context.Module.FindAsync(id);
            _context.Module.Remove(module);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}
