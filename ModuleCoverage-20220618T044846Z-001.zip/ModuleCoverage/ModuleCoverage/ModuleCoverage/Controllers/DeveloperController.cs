﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ModuleCoverage.Data;
using ModuleCoverage.Models;

namespace ModuleCoverage.Controllers
{
    public class DeveloperController : Controller
    {
        private readonly ModuleCoverageContext _context;

        public DeveloperController(ModuleCoverageContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var developerViewModelList = _context.Developer
                                                 .Include(d => d.DeveloperModules)
                                                 .Select(x => new DeveloperView
                                                 {
                                                     Id = x.Id,
                                                     Name = x.Name,
                                                     Email = x.Email,
                                                     OfficeId = x.OfficeId,
                                                     ModuleNameList = x.DeveloperModules
                                                                       .Select(y => y.Module.Name).ToList(),
                                                     CoveredModules = x.DeveloperModules
                                                                              .Select(dvm => new DeveloperModuleView
                                                                              {
                                                                                  ModuleId = dvm.ModuleId,
                                                                                  ModuleName = _context.Module
                                                                                                       .Where(z=>z.Id==dvm.ModuleId)
                                                                                                       .Select(p=>p.Name)
                                                                                                       .FirstOrDefault(),
                                                                                  IsCovered = true,
                                                                                  Percentage = dvm.Percentage
                                                                                                
                                                                              }).ToList()

                                                 }).ToList();
            return View(developerViewModelList);
        }

        public IActionResult Create()
        {
            var model = new DeveloperView();
            model.CoveredModules = _context.Module
                                      .Select(x => new DeveloperModuleView
                                      {
                                          ModuleId = x.Id,
                                          IsCovered = false,
                                          ModuleName = x.Name
                                      }).ToList();

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,Email,OfficeId,CoveredModules")] DeveloperView developerVM)
        {
            if (ModelState.IsValid)
            {
                foreach(var x in developerVM.CoveredModules)    if(x.IsCovered==false)x.Percentage = 0;
                
                Developer developer = new Developer
                {
                    Id = developerVM.Id,
                    Name = developerVM.Name,
                    Email = developerVM.Email,
                    OfficeId = developerVM.OfficeId,
                    DeveloperModules = developerVM.CoveredModules.Where(y => y.IsCovered == true).Select(x => new DeveloperModule
                    {
                        DeveloperId = developerVM.Id,
                        ModuleId = x.ModuleId,
                        Percentage = x.Percentage
                    }).ToList()
                };

                _context.Developer.Add(developer);
                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }

            return View(developerVM);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var developerVM = _context.Developer
                                    .Include(x => x.DeveloperModules)
                                    .Where(y => y.Id == id)
                                    .Select(dv => new DeveloperView
                                    {
                                        Id = dv.Id,
                                        Name = dv.Name,
                                        Email = dv.Email,
                                        OfficeId = dv.OfficeId,
                                        CoveredModules = _context.Module.Select(dm => new DeveloperModuleView
                                                                        {
                                                                            ModuleId = dm.Id,
                                                                            IsCovered = dv.DeveloperModules.Any(dvm => dvm.ModuleId == dm.Id),
                                                                            ModuleName = dm.Name,
                                                                            Percentage = dv.DeveloperModules.Where(y=>y.DeveloperId==id && y.ModuleId==dm.Id).Select(x=> x.Percentage).FirstOrDefault()
                                                                        }).ToList()
                                    }).FirstOrDefault();

            if (developerVM == null)
            {
                return NotFound();
            }

            return View(developerVM);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Email,OfficeId,CoveredModules")] DeveloperView developerVM)
            {
            if (id != developerVM.Id)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                foreach (var x in developerVM.CoveredModules) if (x.IsCovered == false) x.Percentage = 0;
                //Create an Developer Object
                Developer developer = _context.Developer
                                              .Include(d => d.DeveloperModules)
                                              .Where(d => d.Id == developerVM.Id)
                                              .FirstOrDefault();

                if (developer == null)
                {
                    return NotFound();
                }

                developer.Name = developerVM.Name;
                developer.Email = developerVM.Email;
                developer.OfficeId = developerVM.OfficeId;
                
                developer.DeveloperModules = developerVM.CoveredModules
                                                      .Where(y => y.IsCovered == true)
                                                      .Select(x => new DeveloperModule
                                                      {
                                                          DeveloperId = developer.Id,
                                                          ModuleId = x.ModuleId,
                                                          Percentage = x.Percentage
                                                      }).ToList();

                try
                {
                    _context.Update(developer);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DeveloperExists(developer.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(developerVM);
        }

        private bool DeveloperExists(int id)
        {
            return _context.Developer.Any(e => e.Id == id);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var developer = await _context.Developer
                                          .FirstOrDefaultAsync(m => m.Id == id);
            if (developer == null)
            {
                return NotFound();
            }

            return View(developer);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var developer = await _context.Developer.FindAsync(id);
            _context.Developer.Remove(developer);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}
