﻿using System.ComponentModel.DataAnnotations;

namespace ModuleCoverage.Models
{
    public class Module
    {
        public Module()
        {
            DeveloperModules = new List<DeveloperModule>();
        }
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }
        
        public List<DeveloperModule> DeveloperModules { get; set; }

    }
}
