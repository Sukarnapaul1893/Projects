﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ModuleCoverage.Models
{
    public class Developer
    {
        
        public Developer()
        {
            DeveloperModules = new List<DeveloperModule>();
        }
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        [RegularExpression(@"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$",
        ErrorMessage = "Invalid email format")]
        public string Email { get; set; }

        [Required]
        public int OfficeId { get; set; }

        public List<DeveloperModule> DeveloperModules { get; set; }
    }
}
