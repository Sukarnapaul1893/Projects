﻿namespace ModuleCoverage.Models
{
    public class DeveloperModule
    {
        public int Id { get; set; }
        public int DeveloperId { get; set; }
        public Developer Developer { get; set; }
        public int ModuleId { get; set; }
        public double Percentage { get; set; }
        public Module Module { get; set; }

    }
}
