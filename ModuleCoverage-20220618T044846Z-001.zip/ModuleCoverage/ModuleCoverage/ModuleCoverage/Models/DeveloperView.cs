﻿using System.ComponentModel.DataAnnotations;

namespace ModuleCoverage.Models
{
    public class DeveloperView
    {
        public DeveloperView()
        {
            ModuleNameList = new List<string>();
            CoveredModules = new List<DeveloperModuleView>();
        }

        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        [RegularExpression(@"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$",
        ErrorMessage = "Invalid email format")]
        public string Email { get; set; }

        [Required]
        public int OfficeId { get; set; }

        public List<string> ModuleNameList { get; set; }

        public List<DeveloperModuleView> CoveredModules { get; set; }
    }
}
