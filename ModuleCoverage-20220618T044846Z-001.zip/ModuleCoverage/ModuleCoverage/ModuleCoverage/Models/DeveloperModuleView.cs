﻿namespace ModuleCoverage.Models
{
    public class DeveloperModuleView
    {
        public int Id { get; set; }
        public int ModuleId { get; set; }
        public bool IsCovered { get; set; }
        public string ModuleName { get; set; }
        public double Percentage { get; set; }
    }
}
