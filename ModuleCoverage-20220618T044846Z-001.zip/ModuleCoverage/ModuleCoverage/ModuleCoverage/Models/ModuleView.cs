﻿using System.ComponentModel.DataAnnotations;

namespace ModuleCoverage.Models
{
    public class ModuleView
    {
        public ModuleView()
        {
            MostExperiencedDeveloper = "";
        }
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }
        public string MostExperiencedDeveloper { get; set; }
        public double AverageCoveredPercentage { get; set; }
        public int TotalNumberOfDevelopers { get; set; }
    }
}
