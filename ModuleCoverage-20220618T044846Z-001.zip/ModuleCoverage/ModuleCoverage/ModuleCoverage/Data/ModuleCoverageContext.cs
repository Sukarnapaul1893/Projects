﻿#nullable disable
using Microsoft.EntityFrameworkCore;
using ModuleCoverage.Models;

namespace ModuleCoverage.Data
{
    public class ModuleCoverageContext : DbContext
    {
        public ModuleCoverageContext(DbContextOptions<ModuleCoverageContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<DeveloperModule>()
                    .HasOne(d => d.Developer)
                    .WithMany(dm => dm.DeveloperModules)
                    .HasForeignKey(di => di.DeveloperId)
                    .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<DeveloperModule>()
                    .HasOne(m => m.Module)
                    .WithMany(dm => dm.DeveloperModules)
                    .HasForeignKey(mi => mi.ModuleId)
                    .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<DeveloperModule>()
                    .Property(b => b.Percentage)
                    .HasDefaultValue(3.6);
        }
        public DbSet<Developer> Developer { get; set; }
        public DbSet<Module> Module { get; set; }
        public DbSet<DeveloperModule> DeveloperModules { get; set; }
    }
}
