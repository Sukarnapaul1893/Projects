﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ModuleCoverage.Migrations
{
    public partial class Percentage : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<double>(
                name: "Percentage",
                table: "DeveloperModules",
                type: "float",
                nullable: false,
                defaultValue: 0.0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Percentage",
                table: "DeveloperModules");
        }
    }
}
